## ----eval=FALSE----------------------------------------------------------
#      # first check to see if dependency package is installed. If not, install from cran???
#      list.packages <- c("plyr","ggplot2","data.table","stringr", "knitr", "rmarkdown")
#      new.packages <- list.packages[!(list.packages %in% installed.packages()[,"Package"])]
#      if(length(new.packages)) install.packages(new.packages, repos="http://cran.rstudio.com/")
#  
#      install.packages("path/to/ShedsHT_0.1.1.tar.gz", repos = NULL, type = "source")

## ----eval=FALSE----------------------------------------------------------
#    library(ShedsHT)

## ----eval=FALSE----------------------------------------------------------
#      vignette("ShedsHT")

## ----eval=FALSE----------------------------------------------------------
#      help(package="ShedsHT")

